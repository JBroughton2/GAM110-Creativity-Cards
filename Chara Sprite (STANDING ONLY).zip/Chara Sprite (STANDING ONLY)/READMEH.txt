This only contains the standing sprite; remaining sprites will be uploaded by the end of today

((again, be sure to format the sprite to "RGBA 32" to prevent colour fuckery))