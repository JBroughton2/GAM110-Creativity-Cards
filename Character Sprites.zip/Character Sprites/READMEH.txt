Contains the standing, running, and jumping sprites; lemme know if there's anything to be changed ASAP
((again, be sure to format the sprite to "RGBA 32" to prevent colour fuckery))